﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WongaTest
{
    [ServiceContract]
    public interface IWongaService
    {
        [OperationContract]
        void GetName(string Name);
    }
}
