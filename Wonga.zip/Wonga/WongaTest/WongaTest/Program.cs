﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace WongaTest
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost hostServ = new ServiceHost(typeof(WongaService));
            hostServ.Open();
            Console.WriteLine("This is a Receiver Console");
            Console.ReadLine();

        }
    }
}
