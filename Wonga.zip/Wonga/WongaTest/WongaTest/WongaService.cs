﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WongaTest
{
    [ServiceBehavior]
    public class WongaService : IWongaService
    {
        [OperationBehavior]
        public void GetName(string Name)
        {
            Console.WriteLine("Hello {0}, I am your Father!", Name);
        }
    }
}
