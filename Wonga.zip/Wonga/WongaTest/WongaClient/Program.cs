﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WongaClient.ServiceRef;

namespace WongaClient
{
    class Program
    {
        static void Main(string[] args)
        {
            WongaServiceClient client = new ServiceRef.WongaServiceClient();
            Console.WriteLine("Please Enter Your Name");
            string Name = Console.ReadLine();

            client.GetName(Name);

            if (Name != string.Empty || Name != null)
            {
                
                Console.WriteLine("Please Enter Your Name");
                Name = Console.ReadLine();
                client.GetName(Name);
            }
            client.Close();
        }
    }
}
